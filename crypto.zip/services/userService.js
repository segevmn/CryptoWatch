const Watchlist = require('../models/watchlist');
const User = require('../models/user');

const userService = {
  getUserWatchlist: async userId => {
    const watchlistEntries = await Watchlist.find({ userId });
    if (!watchlistEntries) {
      throw new Error('No watchlist entries found for this user');
    }
    return watchlistEntries.coins;
  },

  addCoinToWatchlist: async (userId, coin) => {
    let watchlist = await Watchlist.findOne({ userId });
    if (!watchlist) {
      watchlist = new Watchlist({ userId, coins: [coin] });
    } else {
      if (!watchlist.coins.includes(coin)) {
        watchlist.coins.push(coin);
      } else {
        throw new Error('Coin is already in watchlist');
      }
    }
    return await watchlist.save();
  },

  deleteUser: async userId => {
    const result = await User.deleteOne({ _id: userId });
    if (result.deletedCount === 0) {
      throw new Error('User not found');
    }
    await Watchlist.deleteOne({ userId });
    logger.info(`User ${userId} and watchlist deleted`);
  },
};

module.exports = userService;
